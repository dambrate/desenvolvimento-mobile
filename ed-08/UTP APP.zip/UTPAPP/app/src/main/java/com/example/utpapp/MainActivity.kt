package com.example.utpapp

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.utpapp.databinding.ActivityHomeBinding
import com.example.utpapp.databinding.ActivityMainBinding
import com.example.utpapp.view.Home
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        binding.btLogin.setOnClickListener {
            val nome = binding.editNome.text.toString()
            val senha = binding.editSenha.text.toString()

            when{
                nome.isEmpty() -> {
                    mensagem(it, "Coloque o seu nome!")

                }senha.isEmpty() -> {
                    mensagem(it,"Preencha a senha!")
                }senha.lenght <=5 ->{
                    mensagem(it,"A senha precisa ter pelo menos 6 caracters")
                }

                }else -> {
                    navegarPraHome(nome)
            }
        }
    }
    private fun mensagem(view: View, mensagem : String){
        val snackbar = Snackbar.make(view,mensagem,Snackbar.LENGTH_SHORT)
        snackbar.setBackgroundTint(Color.parseColor("#FF000"))
        snackbar.setTextColor(Color.parseColor("#FFFFFF"))
        snackbar.show()
    }

    private fun navegarPraHome(){
        val intent = getIntent(this, Home::class.java)
        intent.putExtra("nome", nome)
    }
}